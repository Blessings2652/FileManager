package com.theblacksheep.filemanager.engine

import rikka.shizuku.Shizuku

/**
 * Shizuku-based file access. Runs commands via Shizuku's privileged process
 * (adb/shell UID), giving broader access than SAF without requiring root.
 *
 * NOTE: This is a scaffold. Real command execution should go through
 * Shizuku's IRemoteProcess (see Shizuku-API demo for IUserService/AIDL setup)
 * rather than Runtime.exec, which will NOT gain shell privileges on its own.
 */
class ShizukuEngine : FileAccessEngine {

    override val id = EngineType.SHIZUKU

    override suspend fun isAvailable(): Boolean =
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED

    override suspend fun requestAccess(): Boolean {
        if (!Shizuku.pingBinder()) return false
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(REQUEST_CODE)
        }
        return Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    override suspend fun listFiles(path: String): List<FileEntry> {
        // TODO: implement via Shizuku IRemoteProcess running `ls -la`, parse output.
        return emptyList()
    }

    override suspend fun delete(path: String): Boolean = false // TODO
    override suspend fun rename(path: String, newName: String): Boolean = false // TODO
    override suspend fun copy(sourcePath: String, destPath: String): Boolean = false // TODO
    override suspend fun move(sourcePath: String, destPath: String): Boolean = false // TODO
    override suspend fun mkdir(path: String): Boolean = false // TODO
    override suspend fun readBytes(path: String): ByteArray? = null // TODO
    override suspend fun writeBytes(path: String, data: ByteArray): Boolean = false // TODO

    companion object {
        const val REQUEST_CODE = 1001
    }
}
