package com.theblacksheep.filemanager.engine

import com.topjohnwu.superuser.Shell
import com.topjohnwu.superuser.io.SuFile

/**
 * Root-based file access via libsu. Shells out to `su` for all operations,
 * so it works regardless of SELinux/SAF restrictions as long as the device
 * is rooted and the app has been granted su.
 */
class RootEngine : FileAccessEngine {

    override val id = EngineType.ROOT

    override suspend fun isAvailable(): Boolean = Shell.getShell().isRoot

    override suspend fun requestAccess(): Boolean {
        // Triggers the root prompt (Magisk) if not already granted.
        return Shell.getShell().isRoot
    }

    override suspend fun listFiles(path: String): List<FileEntry> {
        val dir = SuFile(path)
        return dir.listFiles()?.map { f ->
            FileEntry(
                name = f.name,
                path = f.absolutePath,
                isDirectory = f.isDirectory,
                sizeBytes = f.length(),
                lastModified = f.lastModified()
            )
        } ?: emptyList()
    }

    override suspend fun delete(path: String): Boolean =
        Shell.cmd("rm -rf '$path'").exec().isSuccess

    override suspend fun rename(path: String, newName: String): Boolean {
        val parent = SuFile(path).parent
        return Shell.cmd("mv '$path' '$parent/$newName'").exec().isSuccess
    }

    override suspend fun copy(sourcePath: String, destPath: String): Boolean =
        Shell.cmd("cp -r '$sourcePath' '$destPath'").exec().isSuccess

    override suspend fun move(sourcePath: String, destPath: String): Boolean =
        Shell.cmd("mv '$sourcePath' '$destPath'").exec().isSuccess

    override suspend fun mkdir(path: String): Boolean =
        Shell.cmd("mkdir -p '$path'").exec().isSuccess

    override suspend fun readBytes(path: String): ByteArray? =
        try { SuFile(path).newInputStream().use { it.readBytes() } } catch (e: Exception) { null }

    override suspend fun writeBytes(path: String, data: ByteArray): Boolean =
        try { SuFile(path).newOutputStream().use { it.write(data) }; true } catch (e: Exception) { false }
}
