package com.theblacksheep.filemanager.engine

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/**
 * Storage Access Framework engine. No root/Shizuku needed, but scoped to
 * whatever tree URI the user grants via ACTION_OPEN_DOCUMENT_TREE, and
 * generally slower for bulk operations than Root/Shizuku.
 */
class SafEngine(
    private val context: Context,
    private var treeUri: Uri? = null
) : FileAccessEngine {

    override val id = EngineType.SAF

    override suspend fun isAvailable(): Boolean = treeUri != null

    override suspend fun requestAccess(): Boolean {
        // Actual ACTION_OPEN_DOCUMENT_TREE launch + persistable permission
        // grant happens in the Activity; treeUri is injected here afterward.
        return treeUri != null
    }

    fun setTreeUri(uri: Uri) {
        treeUri = uri
        context.contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
    }

    override suspend fun listFiles(path: String): List<FileEntry> {
        val root = treeUri?.let { DocumentFile.fromTreeUri(context, it) } ?: return emptyList()
        val dir = findByPath(root, path) ?: root
        return dir.listFiles().map {
            FileEntry(
                name = it.name ?: "",
                path = it.uri.toString(),
                isDirectory = it.isDirectory,
                sizeBytes = it.length(),
                lastModified = it.lastModified()
            )
        }
    }

    override suspend fun delete(path: String): Boolean =
        DocumentFile.fromSingleUri(context, Uri.parse(path))?.delete() ?: false

    override suspend fun rename(path: String, newName: String): Boolean =
        DocumentFile.fromSingleUri(context, Uri.parse(path))?.renameTo(newName) ?: false

    override suspend fun copy(sourcePath: String, destPath: String): Boolean = false // TODO
    override suspend fun move(sourcePath: String, destPath: String): Boolean = false // TODO

    override suspend fun mkdir(path: String): Boolean = false // TODO

    override suspend fun readBytes(path: String): ByteArray? =
        try {
            context.contentResolver.openInputStream(Uri.parse(path))?.use { it.readBytes() }
        } catch (e: Exception) { null }

    override suspend fun writeBytes(path: String, data: ByteArray): Boolean =
        try {
            context.contentResolver.openOutputStream(Uri.parse(path))?.use { it.write(data) }
            true
        } catch (e: Exception) { false }

    private fun findByPath(root: DocumentFile, path: String): DocumentFile? {
        if (path.isBlank() || path == "/") return root
        var current = root
        for (segment in path.trim('/').split("/")) {
            current = current.findFile(segment) ?: return null
        }
        return current
    }
}
