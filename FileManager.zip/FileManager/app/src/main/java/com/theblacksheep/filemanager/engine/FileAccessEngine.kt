package com.theblacksheep.filemanager.engine

/**
 * Abstraction over the different ways this app can read/write the filesystem.
 * The user picks the engine at runtime from Settings; MainViewModel swaps
 * the active implementation without the UI layer knowing which one is used.
 */
interface FileAccessEngine {

    val id: EngineType

    /** True if this engine's prerequisites (root/Shizuku/permission) are satisfied. */
    suspend fun isAvailable(): Boolean

    /** Request whatever grant this engine needs (root prompt, Shizuku permission, SAF picker). */
    suspend fun requestAccess(): Boolean

    suspend fun listFiles(path: String): List<FileEntry>

    suspend fun delete(path: String): Boolean

    suspend fun rename(path: String, newName: String): Boolean

    suspend fun copy(sourcePath: String, destPath: String): Boolean

    suspend fun move(sourcePath: String, destPath: String): Boolean

    suspend fun mkdir(path: String): Boolean

    suspend fun readBytes(path: String): ByteArray?

    suspend fun writeBytes(path: String, data: ByteArray): Boolean
}

enum class EngineType {
    SHIZUKU,
    ROOT,
    SAF
}

data class FileEntry(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val permissions: String? = null
)
