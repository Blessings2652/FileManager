package com.theblacksheep.filemanager.engine

import android.content.Context

/**
 * Holds the currently-selected engine and lets the UI switch at runtime
 * (e.g. from a Settings screen) without restarting the app.
 */
class EngineProvider(private val context: Context) {

    private val rootEngine by lazy { RootEngine() }
    private val shizukuEngine by lazy { ShizukuEngine() }
    private val safEngine by lazy { SafEngine(context) }

    var current: FileAccessEngine = safEngine
        private set

    fun select(type: EngineType): FileAccessEngine {
        current = when (type) {
            EngineType.ROOT -> rootEngine
            EngineType.SHIZUKU -> shizukuEngine
            EngineType.SAF -> safEngine
        }
        return current
    }

    fun engineFor(type: EngineType): FileAccessEngine = when (type) {
        EngineType.ROOT -> rootEngine
        EngineType.SHIZUKU -> shizukuEngine
        EngineType.SAF -> safEngine
    }
}
