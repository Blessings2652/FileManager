package com.theblacksheep.filemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.theblacksheep.filemanager.engine.EngineProvider
import com.theblacksheep.filemanager.engine.EngineType
import com.theblacksheep.filemanager.engine.FileEntry
import com.theblacksheep.filemanager.ui.theme.FileManagerTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var engineProvider: EngineProvider

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engineProvider = EngineProvider(applicationContext)

        setContent {
            FileManagerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FileManagerScreen(engineProvider)
                }
            }
        }
    }
}

@Composable
fun FileManagerScreen(engineProvider: EngineProvider) {
    var selectedEngine by remember { mutableStateOf(EngineType.SAF) }
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("File Manager", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))

        Row {
            EngineType.entries.forEach { type ->
                FilterChip(
                    selected = selectedEngine == type,
                    onClick = {
                        selectedEngine = type
                        engineProvider.select(type)
                    },
                    label = { Text(type.name) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            scope.launch {
                val engine = engineProvider.select(selectedEngine)
                if (!engine.isAvailable()) engine.requestAccess()
                entries = engine.listFiles("/storage/emulated/0")
            }
        }) {
            Text("Load /storage/emulated/0")
        }

        Spacer(Modifier.height(16.dp))

        LazyColumnEntries(entries)
    }
}

@Composable
fun LazyColumnEntries(entries: List<FileEntry>) {
    androidx.compose.foundation.lazy.LazyColumn {
        items(entries) { entry ->
            ListItem(
                headlineContent = { Text(entry.name) },
                supportingContent = { Text(if (entry.isDirectory) "Folder" else "${entry.sizeBytes} bytes") }
            )
            Divider()
        }
    }
}
